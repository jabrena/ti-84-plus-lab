
 DDDDDDDDDDD  OOOOOOOOOOO  OOOOOOOOOOO  MMMM   MMMM 
 D	   D  O         O  O         O  M   M M   M
 D  DDDDD  D  O  OOOOO  O  O  OOOOO  O  M    M    M
 D  D   D  D  O  O   O  O  O  O   O  O  M  M   M  M
 D  D   D  D  O  O   O  O  O  O   O  O  M  MM MM  M
 D  D  D   D   O  O O  O    O  O O  O   M  M M M  M
 D  D D	  D     O  O  O      O  O  O     M M   M  M
 D  DD   D       O   O        O   O       MM   M  M
 D      D         OOO   8      OOO         M   M  M
 D     D               8 8                     M  M
 D    D               8   8                    M  M
 D   D                 8 8  333                 M M
 D  D        for TI     8      3                 MM
 DDD                   8 8      3    (  +  )      M
                      8   8    3    (   +   )
                       8 8    3     (+++++++)
                        8      3    (   +   )
                                3    (  +  )
                               3   
                            333 

By  Rapha�l Siryani   email:Ironraph@aol.com
and Alexis Guinamard  email:alexis-guinamard@fr.st
We are both TIFT members
http://www.doom83.fr.st
http://www.tift.fr.st (in french)
-------------------------------------------------------------------------

Doom for ti83 is the first Doom-like in real 3D for the 83(+)!!

   We wanted for some time to make a doom-like, in real 3d on the 
83+, because there was no game of this kind... We thus put ourselves
at the job one year ago, and today the game begins to run correctly. 

----=Doom is still in developement=----
  Doom is still in dvelopement, this is why the game's graphics are sometime
quite basic, it will change in the future versions, also, The IA is exteamly
basic, because we have done it in five minutes to have a playable game for the
ti-cas contest, the monsters can actualy hit you if they don't see you, but you
can only hit a monster when you see it. So, don't try to hide behind a wall 
because monsters hit you till their death...
Also, don't press [2nde]+[quit] in the menu, it would crash the calc some times
after (because of the getkey call). Doom might not crash in other case the calc.

----=Requierements:=-----
  To play at Doom, you'll need a ti83 with ion installed, or a ti83+
with MirageOS (Doom didn't work properly under ion with the 83+, 
so I compile it as a MirageOS prog...), You will also need about
14.5 kb of free ram...

--------=Keys:=--------
[Up]    Move forward
[Down]  Move backward
[<-]    Turn left
[->]    Turn right
[F4]	Strafe left
[F5]	Strafe right
[2nde]	Fire!
[Alpha]	run
[F1]	First weapon
[F2]	Second weapon
[clear] Retunrn to the main menu

---------=News=---------
05/06/02: v0.97c
This version is released on ticalc.org, we fixed a bug that appends
verry rarely while changing the level on 83+ (in fact, the same as 
the one which crashed the calc while exiting), and the 83+ version
is now only for MirageOS.

14/05/02: v0.97b
Addition of a menu, and options, only the adjustment of contrast
max works for the moment, but the adjustment of the difficulty and
the tremors of the screen will come quickly... Moreover, the bug 
which crash some times while exitting is fixed. 

10/05/02: v0.97 
Several bugs of displaying were corrected, and a problem with the 
interruptions of Ti-OS also, the play is more fluid, and 
displaying is cleaner! 

10/05/02: v0.96
The so much awaited 83'-' version is finally functional! Moreover,
the division made in a table was replaced by another calculated, 
the program thus lost 2500 bytes! Finally a bug which made display the 
sprites several times on the same image was solved It thus doesen't
have there more the deceleration by displaying several items!   
 
20/03/02: v0.95
The side bar starts to be functional: the life and amo are now 
displayed.  



----=FEATURES:=----
Doom already include:

*Some options
*83(ion)/83+(MirageOS) support
*3D Engine almost finnished
*amo and life 
*sprites and items
*Monsters can shoot exteamly basicaly
*Dark rooms and normal rooms
*tremors of the screen when a monster hit you
*you can walk, run turn and straff 
*side bar (life and amo)

---=WHAT WILL BE MADE:=---
*monsters with a 'real' AI
*link support for deathmatch
*Side bar with weapon displayed, and some other stuff
*Externals levels
*Levels compression to reduce doom's size
*some bugs to fix...

--------=Credit:=-------- 
We want to thank all the programmers who helped us to carry out this 
project, in particular Yhean, Paxl, TCPA's members, but also badja for
his line routine and Joe Wingbermuehle for his sprite and for copy of
graphbuffer routines ... 


NOTE:Don't play at Doom on an emulator as VTI which does not show all the 
functionalities of the play and is verry slower... 

DISCLAIMER: We are not responsible of any problems caused to your ti with doom...